1) Expand the .Zip file, and move Kinect.2.0.1410.19000.UnityPackageto a well known <location>
2) Open UnityPro (you need to have a Pro edition to pull in custom packages and plugins)
3) Create a new project
4) Click on the menu item Assets->Import Package->Custom Package...
5) Navigate to the <location> from step 1
6) Select the Kinect.2.0.1410.19000.UnityPackage
7) Click "Open"
8) Click "Import" in the lower right hand corner of the "Importing Package" Dialog (which Unity will launch after step 7)
9) If you wish to see the Kinect in action there are two sample scenes available from the zip.
10) If you wish to use VisualGestureBuilder within Unity, repeat steps 1 through 8 with Kinect.VisualGestureBuilder.2.0.1410.19000.unitypackage
11) If you wish to use the Face functionality within Unity, repeat steps 1 through 8 with Kinect.Face.2.0.1410.19000.unitypackage
 